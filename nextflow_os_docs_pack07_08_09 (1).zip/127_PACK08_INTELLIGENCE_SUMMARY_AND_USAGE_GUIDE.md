# Nextflow OS – Pack 08 Intelligence, Recommendations and Assistants Summary and Usage Guide

**Document ID:** 127_PACK08_INTELLIGENCE_SUMMARY_AND_USAGE_GUIDE  
**Pack:** 08 — Advanced Intelligence, Recommendations and Assistants  
**Version:** 1.0  
**Status:** Draft v1  
**Primary Owner:** Product Leadership / Data & Intelligence / CS / Ops  

## Cross-pack references

- Xem **000 Global Glossary and Naming Conventions** để hiểu thống nhất các thuật ngữ intelligence (feature, rule, score, model, assistant, AI skill...).  
- Xem **001 OS Master Index and Reading Map** để đặt Pack 08 trong bức tranh OS tổng thể.  
- Sử dụng **129 Pack 08 AI Use Case Record Template** khi mô tả hoặc review từng use case AI cụ thể.  
- Tham khảo **128 Pack 08 Intelligence Execution Prompts Library** để kích hoạt các use cases trong công việc hàng ngày.  

## 1. Pack 08 nói về điều gì?

Pack 08 mô tả cách Nextflow OS thêm **lớp Intelligence, Recommendations and Assistants** lên trên dữ liệu và workflows hiện có: chọn use cases, thiết kế feature layer & logic, đảm bảo AI governance, UX và vận hành lâu dài. [code_file:507]

Nếu Pack 07 giúp bạn "nhìn thấy" hoạt động, thì Pack 08 giúp bạn **ra quyết định và hành động thông minh hơn** dựa trên signals đó.

## 2. Các use case chính (A–E)

Theo 121, các nhóm use case chính là: [code_file:507]

- **A – Work & SLA Intelligence**: 
  - A1: SLA risk & work prioritization.  
  - A2: queue load & staffing advisor.  
  - A3: exception patterns & runbook assistant.

- **B – Integrations & Data Quality**:  
  - B1: integration health & risk.  
  - B2: mapping & field suggestion.

- **C – Customer Health & CS**:  
  - C1: customer health scores & drivers.  
  - C2: CS assistants for QBR preparation.

- **D – Knowledge & SOP Assistants**:  
  - D1: assistants giúp truy cập SOPs, policies, runbooks.

- **E – Automation & Process Improvement**:  
  - E1: đề xuất opportunities cho automation và cải tiến quy trình.

## 3. Dùng Pack 08 như thế nào? – góc nhìn CS/Ops/CSM

- Dùng **121** để hiểu những use cases nào đã được "đóng gói" và nên bật ở wedge của bạn. [code_file:507]
- Dùng **125** để biết assistants sẽ xuất hiện ở đâu trong UI, có quyền gì, và người dùng có thể tương tác thế nào. [code_file:511]
- Dùng **128** để biết hỏi gì với assistants và intelligence layer trong công việc hàng ngày (ưu tiên work, chuẩn bị QBR, điều tra exceptions...). [code_file:555]
- Khi outputs có impact lớn (vd gợi ý auto-act), luôn tuân **124**: xem risk level, guardrails và check xem auto-action có được cho phép hay không. [code_file:510]

## 4. Dùng Pack 08 như thế nào? – góc nhìn Product & Data

- Product & Data dùng **129 AI Use Case Record Template** để mô tả từng use case AI cụ thể, trước khi build. [code_file:553]
- Dùng **122** để thiết kế feature layer: tables/views cho signals chung. [code_file:506]
- Dùng **123** để chọn logic pattern (rules, scoring, similarity, RAG), tránh over-engineering. [code_file:509]
- Dùng **124** để gán risk level, guardrails, approvals. [code_file:510]
- Dùng **126** để thiết kế monitoring, feedback, retraining và lộ trình maturity. [code_file:512]

## 5. Liên kết với Packs 07, 06, 09

- Với Pack 07: intelligence dựa trên facts, metrics, KPIs, không tạo silo data. [code_file:479][code_file:480]
- Với Pack 06: AI incidents follow incident & change playbooks, risk tiers & approvals. [code_file:451][code_file:452][code_file:510]
- Với Pack 09: AI skills/assistants có thể được đóng gói thành assets, xuất hiện trong marketplace và chịu review & support theo Pack 09. [code_file:536][code_file:537][code_file:539]

## 6. Điều kiện hoàn thành của Pack 08

Pack 08 được xem là "đủ dùng" khi:
- SMEs hiểu 5 nhóm use case và cách bật chúng;  
- Product & Data có templates, schemas và patterns rõ để build;  
- Governance có framework kiểm soát;  
- người dùng front-line có prompts & UX rõ ràng để khai thác intelligence.

## 7. Illustrative scenario – B2B SaaS CS team dùng Pack 08

Tiếp tục ví dụ B2B SaaS CS phía trên: sau khi đã có dữ liệu & dashboards ổn định (Pack 07), đội muốn thêm intelligence để ưu tiên việc và chăm khách chủ động hơn.

- Product & CS cùng Data chọn vài use cases trong **121**: A1 (ưu tiên tickets có nguy cơ breach SLA), C1 (theo dõi khách health giảm), C2 (chuẩn bị QBR nhanh).  
- Data thiết kế feature layer theo **122**: signals như ticket age, loại yêu cầu, lịch sử breaches, logins, feature adoption.  
- Với **123**, họ chọn logic pattern: rules cho các case đơn giản, scores cho SLA risk, models đơn giản cho health.  
- Governance gán risk tier và guardrails theo **124** (vd khuyến nghị ưu tiên là low/medium risk; khuyến nghị auto-act cần approval).  
- UX thiết kế surfaces cho assistants theo **125** (side panel trong queue, QBR assistant).  
- CS team bắt đầu dùng prompts từ **128**: hỏi assistant xem top việc cần làm hôm nay, khách nào cần chạm trước QBR.  
- Mọi use case được ghi lại bằng template **129**, và ops/feedback follow **126** để cải thiện models và trải nghiệm.


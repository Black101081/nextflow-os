# Nextflow OS – Pack 07 Data, Analytics and Insights Summary and Usage Guide

**Document ID:** 107_PACK07_DATA_ANALYTICS_AND_INSIGHTS_SUMMARY_AND_USAGE_GUIDE  
**Pack:** 07 — Data, Analytics and Insights  
**Version:** 1.0  
**Status:** Draft v1  
**Primary Owner:** Product Leadership / Data & Analytics / Platform  

## Cross-pack references

- Xem **000 Global Glossary and Naming Conventions** để tra cứu thuật ngữ (tenant, wedge, fact, metric, KPI, insight...).  
- Xem **001 OS Master Index and Reading Map** để biết vị trí Pack 07 trong toàn bộ Nextflow OS.  

## 1. Pack 07 nói về điều gì?

Pack 07 định nghĩa **lớp Data, Analytics and Insights** của Nextflow OS – cách dữ liệu được mô hình hoá, lưu trữ, đo lường, hiển thị và vận hành để SMEs có thể nhìn thấy, hiểu và cải thiện vận hành. [code_file:494]

Nếu Pack 02–04 nói "chúng ta làm gì" và Pack 05–06 nói "chúng ta vận hành & govern thế nào", thì Pack 07 trả lời:

> **Dữ liệu lõi và các phép đo chuẩn của Nextflow OS là gì, chúng được mô hình hoá ra sao, và SMEs nên dùng chúng như thế nào trong dashboards, reviews và cải tiến liên tục?** [code_file:479][code_file:480]

## 2. Các tài liệu chính trong Pack 07

- **100_PACK07_DATA_ANALYTICS_AND_INSIGHTS_OVERVIEW_AND_STRATEGY** – định vị vai trò của analytics trong OS, nguyên tắc thiết kế data & dashboards cho SMEs, các wedges & roles chính, và lộ trình maturity. [code_file:494]
- **101_PACK07_DATA_DOMAIN_MODEL_AND_ANALYTICS_SCHEMA** – mô tả data domain model (entities, relationships) và analytics schema (fact/dim tables, grains), là "hợp đồng" giữa platform và analytics. [code_file:479]
- **102_PACK07_METRICS_KPIS_AND_DASHBOARDS_BY_ROLE_AND_WEDGE** – liệt kê KPIs, metrics và dashboards chuẩn cho từng wedge và role (Ops, CS, Finance, Leadership...). [code_file:480]
- **103_PACK07_SELF_SERVICE_ANALYTICS_ENABLEMENT_AND_GOVERNANCE** – mô tả cách bật self-service (explorer, ad-hoc reports) nhưng vẫn giữ governance (certified datasets, access controls). [code_file:481]
- **104_PACK07_DATA_POLICIES_QUALITY_AND_GOVERNANCE** – định nghĩa data classes, data policies, quality metrics, stewardship và review cadence. [code_file:482]
- **105_PACK07_ANALYTICS_OPERATIONS_AND_RUNBOOKS** – hướng dẫn vận hành analytics: refresh jobs, monitoring, incident handling, changes. [code_file:494]
- **109_PACK07_ANALYTICS_EXECUTION_PROMPTS_LIBRARY** – thư viện prompts để CS/Ops/Leadership khai thác insights từ Pack 07 trong công việc hàng ngày. [code_file:493]

## 3. Dùng Pack 07 như thế nào? – góc nhìn tenant admin & business

### 3.1 Tenant admin / business owner

- Dùng **100** để hiểu triết lý analytics của Nextflow OS: data không chỉ để "xem báo cáo" mà để điều hành wedges (Operations, CS, Finance...) theo một bộ KPIs chung. [code_file:494]
- Dùng **102** để chọn bộ KPIs và dashboards chuẩn cho vai trò của mình (vd Head of CS, Ops lead, CEO của SME). [code_file:480]
- Dùng **103** để thiết lập self-service: ai được dùng datasets nào, khi nào dùng dashboard chuẩn, khi nào tự phân tích. [code_file:481]
- Dùng **109** để biết hỏi gì với assistant/analytics layer khi muốn tìm nguyên nhân, cơ hội, rủi ro. [code_file:493]

### 3.2 Data/BI trong SMEs

- Dùng **101** để hiểu schema chuẩn, tránh build song song hoặc lệch với platform. [code_file:479]
- Dùng **104** để biết data class nào nhạy cảm, quality expectations, ai là steward. [code_file:482]
- Dùng **105** để vận hành pipelines, xử lý incidents và thay đổi. [code_file:494]

## 4. Dùng Pack 07 như thế nào? – góc nhìn Product & Platform

- Product dùng **100, 102** để xác định KPIs và dashboards chuẩn khi thiết kế wedges hoặc features mới. [code_file:480][code_file:494]
- Platform/Data Engineering dùng **101, 105** để triển khai warehouse/lakehouse tương thích OS và chạy ổn định. [code_file:479][code_file:494]
- Governance dùng **104** để ensure data policies và quality gắn với Pack 06 risk & incidents. [code_file:482]

## 5. Liên kết Pack 07 với các pack khác

- Với Pack 06: incidents & risk gắn vào facts và metrics để thấy impact và ưu tiên xử lý. [code_file:452][code_file:479]
- Với Pack 08: feature layer và models sử dụng schema & KPIs từ Pack 07. [code_file:506][code_file:507][code_file:508]
- Với Pack 09: marketplace assets (dashboard packs, analytics extensions) dựa trên schema & KPIs chuẩn của Pack 07. [code_file:536][code_file:540]

## 6. Điều kiện hoàn thành của Pack 07

Pack 07 được xem là "đủ dùng" khi:
- bất kỳ wedge/role quan trọng nào cũng có bộ KPIs & dashboards chuẩn;  
- data schema & policies đủ rõ để Data/BI triển khai mà không phát minh lại;  
- analytics được vận hành như một product: có owners, incidents, changes, maturity path.

## 7. Illustrative scenario – B2B SaaS CS team dùng Pack 07

Giả sử một công ty B2B SaaS với đội CS ~10 người muốn chuẩn hoá cách đo lường và review hiệu suất CS.

- Tenant admin và Head of CS đọc **100** để hiểu triết lý analytics và chọn wedge CS làm trọng tâm.  
- Họ dùng **102** để chọn bộ KPIs: response time, resolution time, backlog, SLA hit rate, CSAT, volume theo loại request.  
- Data/BI dùng **101** để map dữ liệu từ công cụ ticketing vào schema chuẩn (facts & dims).  
- Cùng với **103**, họ cấu hình self-service: team leads thấy dashboards chuẩn, agents có view cá nhân, BI vẫn có không gian làm phân tích sâu.  
- Với **105**, họ định nghĩa cách theo dõi refresh, xử lý khi dashboard chậm/có lỗi dữ liệu.  
- Cuối cùng, Head of CS dùng **109** trong các buổi review tuần/tháng để đặt câu hỏi cho assistant: tuần này SLA kém ở đâu, nguyên nhân chính là gì, khách nào có tín hiệu xấu.

